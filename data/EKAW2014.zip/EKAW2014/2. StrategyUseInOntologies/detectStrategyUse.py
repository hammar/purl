#!/usr/bin/env python

import os
import rdflib
import sys

from rdflib import RDF,RDFS,OWL

def main():
	# Iterate over all ontologies, parsing each into a graph
	for fileName in os.listdir("mergedOntologies"):
		if fileName == ".DS_Store":
			continue
		filePath = os.path.join("mergedOntologies",fileName)
		g = rdflib.Graph()
		g.parse(filePath)
		
		# Set initial counter to zero
		propertiesWithDomainOrRange = []
		restrictionProperties = []
		
		# Compute nr of object properties with domain or range definitions defined in graph
		for subProperty,superProperty in g.subject_objects(predicate=RDFS.subPropertyOf):
			if ((subProperty,RDFS.domain,None) in g):
				propertiesWithDomainOrRange.append(subProperty)
 			if ((subProperty,RDFS.range,None) in g):
				propertiesWithDomainOrRange.append(subProperty)
		
		# Compute instances of emulated range restriction
		for s,o in g.subject_objects(predicate=RDFS.subClassOf):
			if (o, OWL.allValuesFrom, None) in g:
				restrictionProperty = g.value(subject=o,predicate=OWL.onProperty)
				restrictionProperties.append(restrictionProperty)
		
		# Compute instances of emulated domain restriction
		for s,o in g.subject_objects(predicate=OWL.equivalentClass):
			if (o, OWL.someValuesFrom, None) in g:
				restrictionProperty = g.value(subject=o,predicate=OWL.onProperty)
				restrictionProperties.append(restrictionProperty)
		
		strategy = ""
		
		if len(set(restrictionProperties).intersection(set(propertiesWithDomainOrRange))) > 0:
			strategy = "Hybrid"
		
		elif len(propertiesWithDomainOrRange) == 0 and len(restrictionProperties) == 0:
			strategy = "Unsupported"
		
		elif len(propertiesWithDomainOrRange) > len(restrictionProperties):
			strategy = "Property-oriented"
		
		else:
			strategy = "Class-oriented"
		
		print("%s;%s strategy"%(fileName,strategy))

if __name__ == '__main__':
	main()