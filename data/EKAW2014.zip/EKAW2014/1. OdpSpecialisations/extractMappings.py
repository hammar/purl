#!/usr/bin/env python

import os
import pprint
import rdflib
import sys

from rdflib import RDF,RDFS,OWL

"""Check whether an entity is defined in a given RDF graph

This simply checks if the entity is typed in the graph, that is, if there 
exists an RDF triple such that the entity is the subject, and rdf:type is
the predicate. Since RDFlib operates on RDF level as opposed to OWL this is 
as close as we are likely to get to a real definition.
Returns boolean True or False.
"""
def isEntityDefinedIn(entity,graph):
	if (entity, RDF.type, None) in graph:
		return True
	else:
		return False


"""Check whether an entity is a set operation

This simply checks whether the entity is linked via one of the set operation
predicates (owl:complementOf, owl:intersectionOf, owl:unionOf) to either another
class or an RDF listing of classes.
"""
def isSetOperation(entity, graph):
	setOperationPredicates = [OWL.complementOf, OWL.intersectionOf, OWL.unionOf]
	for predicate in setOperationPredicates:
		if (entity, predicate, None) in graph:
			return True
	return False

def isOwlRestriction(entity, graph):
	if (entity, RDF.type, OWL.Restriction) in graph:
		return True
	return False


"""Main method

Iterates over the graph defined in the file that is given as first script 
argument and finds mappings between two classes or properties defined in different
graphs. Those mappings are exported to a mappings file, and the graph minus
those mappings are exported to a new graph file.
"""
def main():
	# Set up joint mappings graph
	mappings = rdflib.Graph()
	# Set up setOperations list for later study
	setOperationsList = []
	
	# Iterate over all ontologies, parsing each into a graph
	for fileName in os.listdir("specialisations"):
		if fileName == ".DS_Store":
			continue
	
		filePath = os.path.join("specialisations",fileName)
		g = rdflib.Graph()
		g.parse(filePath, format="xml")
		
		# Iterate over each mapping predicate and each triple containing said predicate
		mappingPredicates = [RDFS.subClassOf, OWL.equivalentClass, RDFS.subPropertyOf, OWL.equivalentProperty]
		for mappingPredicate in mappingPredicates:
			for s,o in g.subject_objects(predicate=mappingPredicate):
				
				# If both subject and object are in AMI namespace, skip and continue
				if ("http://www.ontologydesignpatterns.org/iks/ami/" in s) and ("http://www.ontologydesignpatterns.org/iks/ami/" in o):
					continue
				
				# Store set operations for later manual check
				if isSetOperation(o,g) or isOwlRestriction(o,g):
					setOperationsList.append("%s;%s"%(fileName,unicode(s)))
					print("Set operation appended: %s;%s"%(fileName,unicode(s)))
					continue
				
				# Shortcut: if either subject or object (but not both) is from the ODP portal namespace, consider this a mapping
				if ("http://www.ontologydesignpatterns.org/cp/owl/" in s) != ("http://www.ontologydesignpatterns.org/cp/owl/" in o):
					mappings.add((s,mappingPredicate,o))
					print("(%s) Mapping added: %s %s %s"%(fileName,unicode(s),unicode(mappingPredicate),unicode(o)))
					continue
				
				# If subject and object are defined in different graphs (!= means XOR), treat them
				if isEntityDefinedIn(s,g) != isEntityDefinedIn(o,g) and not (o == OWL.Thing):
					print("--------------------")
					print("Subject:\t%s"%unicode(s))
					print("Predicate:\t%s"%unicode(mappingPredicate))
					print("Object:\t\t%s"%unicode(o))
					print("File:\t\t%s"%fileName)
					
					# The below added as manual verification of mapping axioms, to avoid incorrect
					# mappings being generated from modularly constructed ontologies.
					input_var = raw_input("Is the above a mapping axiom? (Y/N)")
					if (input_var.lower() == "y"):
						mappings.add((s,mappingPredicate,o))
		
		# resave graph in turtle format for easy lookup of set operations
		destinationFile = "turtle/" + fileName.split("/")[-1] + ".ttl"
		g.serialize(destination=destinationFile, format="turtle")
		
	# save set operations list for manual check
	setOperationsFile = open('setOperations.txt', 'w')
	for setOperation in setOperationsList:
		setOperationsFile.write("%s\n"%setOperation)
	setOperationsFile.close()
		
	# save joint mappings to a new file
	mappings.serialize(destination="simpleMappings.ttl", format="turtle")

if __name__ == '__main__':
	main()

